TEXT_TITLE_FORM_CREATE_ENTITY = "Создать сущность"
TEXT_TITLE_FORM_CREATE_GROUP = "Создать группу"