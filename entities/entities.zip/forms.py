from django import forms

class CreateGroupForm(forms.Form):
    group = forms.CharField(label="Группа", max_length=30, required=True)
    name = forms.CharField(label="Название", max_length=30, required=True)
    sort = forms.CharField(label="Сортировка (0 - не отображать на главной странице)", max_length=30, required=False)

    #slug = forms.SlugField(label="Слаг", required=True)
    #parent = forms.CharField(label="Родитель (ID)", required=False)
    
class CreateEntityForm(forms.Form):
    name = forms.CharField(
        label="Название сущности",
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Введите название'})
    )
    #group = forms.CharField(
    #    label="Привязка к группе",
    #    max_length=30,
    #    required=False,
    #    widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Введите ID группы'})
    #)
    #entity = forms.CharField(
    #    label="Привязка к сущности",
    #    max_length=30,
    #    required=False,
    #    widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Введите ID сущности'})
    #)
    sort = forms.CharField(
        label="Сортировка (0 - не отображать на главной странице)",
        max_length=30,
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Введите число'})
    )
    
    
