from django.urls import path
from .views import Entity

urlpatterns = [
    path("", Entity.IndexView.as_view(), name="index-page"),
    path("entity/createGroup/", Entity.CreateGroup.as_view(), name="createGroup"),
    path("entity/createEntity/", Entity.CreateEntity.as_view(), name="createEntity"),
    #path("entity/delete/", Entity..as_view(), name="DeleteEntity"),
    path("entity/get_entity/", Entity.GetEntityOne.as_view(), name="oneEntityView"),
    path("entity/manage/", Entity.Manage.as_view(), name="EntityManageView"),
    path("entity/settings/", Entity.Settings.as_view(), name="EntitySettings"),
]
