db_username_arango = "root"
db_pass_arango = "Kipandopola999"
db_name_arango = "enitities"
db_host_arango = "127.0.0.1:8529"
db_pool_size_arango = 500

db_username_psql = "postgres"
db_pass_psql = "1234"
db_name_psql = "enitities"
db_host_psql = "127.0.0.1:5432"
db_pool_size_psql = 500
db_path_entities_psql = "entities"

DB_PATH_ENTITIES_ARANGO = "enitities"
DB_PATH_EDGES_ARANGO = "edges"
DB_PATH_GROUPS_ARANGO = "groups"