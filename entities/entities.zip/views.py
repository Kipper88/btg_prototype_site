from django.shortcuts import render, redirect
from django.template.loader import render_to_string
from django.http import JsonResponse
from django.views import View
import json
from .forms import CreateGroupForm, CreateEntityForm
from .database.ArangoDB.database_arango import ArangoModelEntity
from .database.ArangoDB import pool as db_pool
from .database.PostgreSQL.database_postgreSQL import PostgreModelEntity
from .constants import *


db_conn_arango = ArangoModelEntity(db_pool)
db_conn_pg = PostgreModelEntity("postgresql+asyncpg://postgres:1234@localhost/entities_data")


class Entity:
    class IndexView(View):
        async def get(self, request):
            entities = await db_conn_arango.get_documents()
            for entity in entities:
                entity["id"] = str(entity["_key"])
            return render(request, "index.html", {"entities": entities, "title_page": "BTG"})


    class CreateGroup(View):
        async def get(self, request):
            form = CreateGroupForm()
            return JsonResponse({"html": render_to_string("entities/form.html", {"form": form, "title_form": TEXT_TITLE_FORM_CREATE_GROUP})})

        async def post(self, request):
            try:
                data = json.loads(request.body)
                form = CreateGroupForm(data)
                if form.is_valid():
                    entity_data = {
                        "group": form.cleaned_data["group"],
                        "name": form.cleaned_data["name"],
                        "sort": form.cleaned_data["sort"],
                    }
                    await db_conn_arango.insert_document(entity_data)
                    return JsonResponse({"status": "success", "message": "Успешно!"})
                return JsonResponse({"status": "error", "message": f"Ошибка! {form.errors.as_json()}"}, status=400)
            except json.JSONDecodeError:
                return JsonResponse({"status": "error", "message": "Неверный формат данных"}, status=400)


    class CreateEntity(View):
        async def get(self, request):
            form = CreateEntityForm()
            return JsonResponse({"html": render_to_string("entities/form.html", {"form": form, "title_form": TEXT_TITLE_FORM_CREATE_ENTITY})})

        async def post(self, request):
            try:
                data = json.loads(request.body)
                form = CreateEntityForm(data)
                if form.is_valid():
                    entity_data = {
                        "name": form.cleaned_data["name"],
                        "sort": form.cleaned_data["sort"]
                    }
                    await db_conn_arango.insert_document(entity_data)
                    return JsonResponse({"status": "success", "message": "Успешно!"})
                return JsonResponse({"status": "error", "message": f"Ошибка! {form.errors.as_json()}"}, status=400)
            except json.JSONDecodeError:
                return JsonResponse({"status": "error", "message": "Неверный формат данных"}, status=400)


    class GetEntityOne(View):
        async def get(self, request):
            entity_id = request.GET.get("entity_id")
            entity = await db_conn_arango.get_document_by_id(entity_id)
            if not entity:
                return JsonResponse({"status": "error", "message": "Сущность не найдена"}, status=404)
            keys = [item.keys() for item in entity.get("data", [])] if entity.get("data") else []
            rows = entity.get("data", [])
            return JsonResponse({"html": render_to_string("entities/table-entity-one.html", {"columns": keys, "rows": rows})})


    class Manage(View):
        async def get(self, request):
            data = await db_conn_arango.get_documents()
            rows = [{"key": i['name'], "name": i['_key']} for i in data]
            html = render_to_string('entities/table-entity-one.html', {"columns": ["имя", "id"], "rows": rows})
            return JsonResponse({"html": html})


    class Settings(View):
        async def get(self, request):
            doc_id = request.GET.get("entity_id")
            data = await db_conn_arango.get_document_by_id(doc_id)
            if not data:
                return JsonResponse({"status": "error", "message": "Сущность не найдена"}, status=404)
            html = render_to_string('settings_entities/settings-enities_page.html', {"columns": ["имя", "id"], "rows": data.get("data", [])})
