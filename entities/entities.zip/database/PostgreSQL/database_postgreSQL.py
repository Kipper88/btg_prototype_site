from sqlalchemy import Table, Column, Integer, String, MetaData, text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import sessionmaker

class PostgreModelEntity:
    def __init__(self, database_url: str):
        """
        Инициализация подключения к базе данных.
        :param database_url: URL для подключения к базе данных (например, "postgresql+asyncpg://user:password@localhost/dbname").
        """
        self.engine = create_async_engine(database_url, echo=True)
        self.async_session = sessionmaker(self.engine, class_=AsyncSession, expire_on_commit=False)

    async def create_table(self, table_name: str, columns: dict):
        """
        Создает таблицу с указанным именем и колонками.
        :param table_name: Имя таблицы.
        :param columns: Словарь, где ключ — имя колонки, значение — тип данных ("string", "integer", "json").
        """
        metadata = MetaData()

        # Преобразуем типы данных из строк в соответствующие классы SQLAlchemy
        type_mapping = {
            "string": String,
            "integer": Integer,
            "json": JSONB,
        }

        # Создаем колонки
        table_columns = [Column(name, type_mapping[type_]) for name, type_ in columns.items()]

        # Добавляем колонку id как первичный ключ
        table_columns.insert(0, Column("id", Integer, primary_key=True, autoincrement=True))

        # Создаем таблицу
        table = Table(table_name, metadata, *table_columns)

        # Создаем таблицу в базе данных
        async with self.engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

    async def insert_data(self, table_name: str, data: dict):
        """
        Вставляет данные в таблицу.
        :param table_name: Имя таблицы.
        :param data: Словарь с данными для вставки.
        """
        async with self.async_session() as session:
            query = text(f"INSERT INTO {table_name} ({', '.join(data.keys())}) VALUES ({', '.join(f':{key}' for key in data.keys())})")
            await session.execute(query, data)
            await session.commit()

    async def fetch_data(self, table_name: str, limit: int = 10):
        """
        Выполняет выборку данных из таблицы с ограничением по количеству строк.
        :param table_name: Имя таблицы.
        :param limit: Ограничение по количеству строк.
        :return: Список строк.
        """
        async with self.async_session() as session:
            query = text(f"SELECT * FROM {table_name} LIMIT :limit")
            result = await session.execute(query, {"limit": limit})
            return result.fetchall()

    async def update_data(self, table_name: str, record_id: int, data: dict):
        """
        Обновляет запись в таблице.
        :param table_name: Имя таблицы.
        :param record_id: ID записи для обновления.
        :param data: Словарь с данными для обновления.
        """
        async with self.async_session() as session:
            set_clause = ", ".join(f"{key} = :{key}" for key in data.keys())
            query = text(f"UPDATE {table_name} SET {set_clause} WHERE id = :id")
            await session.execute(query, {**data, "id": record_id})
            await session.commit()

    async def add_column(self, table_name: str, column_name: str, column_type: str):
        """
        Добавляет новую колонку в таблицу.
        :param table_name: Имя таблицы.
        :param column_name: Имя новой колонки.
        :param column_type: Тип новой колонки ("string", "integer", "json").
        """
        type_mapping = {
            "string": "VARCHAR",
            "integer": "INTEGER",
            "json": "JSONB",
        }
        async with self.async_session() as session:
            query = text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {type_mapping[column_type]}")
            await session.execute(query)
            await session.commit()

    async def drop_column(self, table_name: str, column_name: str):
        """
        Удаляет колонку из таблицы.
        :param table_name: Имя таблицы.
        :param column_name: Имя колонки для удаления.
        """
        async with self.async_session() as session:
            query = text(f"ALTER TABLE {table_name} DROP COLUMN {column_name}")
            await session.execute(query)
            await session.commit()